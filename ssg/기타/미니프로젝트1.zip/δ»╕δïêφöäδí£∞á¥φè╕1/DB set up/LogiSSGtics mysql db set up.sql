
-- Drop all tables
DROP TABLE IF EXISTS `User`;
DROP TABLE IF EXISTS `Product`;
DROP TABLE IF EXISTS `Warehouse`;
DROP TABLE IF EXISTS `Orders`;
DROP TABLE IF EXISTS `Category`;
DROP TABLE IF EXISTS `Brand`;
DROP TABLE IF EXISTS `TrackingNumber`;
DROP TABLE IF EXISTS `ShippingInfo`;
DROP TABLE IF EXISTS `CommonCode`;
DROP TABLE IF EXISTS `shoppingMall`;
DROP TABLE IF EXISTS `Courier`;
DROP TABLE IF EXISTS `order_Insert`;
DROP TABLE IF EXISTS `ShoppingMallList`;
DROP TABLE IF EXISTS `order_shipping`;
DROP TABLE IF EXISTS `Stock`;
DROP TABLE IF EXISTS `ServiceManagement`;
DROP TABLE IF EXISTS `order_takeout`;
DROP TABLE IF EXISTS `boxSize`;
DROP TABLE IF EXISTS `preOrder`;
DROP TABLE IF EXISTS `CommonCodeType`;
DROP TABLE IF EXISTS `Waybill`;
DROP TABLE IF EXISTS `Customer`;
DROP TABLE IF EXISTS `OrderConfirmError`;
DROP TABLE IF EXISTS `DeliveryCategory`;
DROP TABLE IF EXISTS `OrderStatus`;

/*
 Run this query when you want to drop all tables 
-- Drop all foreign key constraints
ALTER TABLE `Orders` DROP FOREIGN KEY `FK_shoppingMall_TO_Orders_1`;
ALTER TABLE `Orders` DROP FOREIGN KEY `FK_shoppingMall_TO_Orders_2`;
ALTER TABLE `TrackingNumber` DROP FOREIGN KEY `FK_Courier_TO_TrackingNumber_1`;
ALTER TABLE `CommonCode` DROP FOREIGN KEY `FK_CommonCodeType_TO_CommonCode_1`;
ALTER TABLE `shoppingMall` DROP FOREIGN KEY `FK_User_TO_shoppingMall_1`;
ALTER TABLE `Stock` DROP FOREIGN KEY `FK_Product_TO_Stock_1`;
ALTER TABLE `Stock` DROP FOREIGN KEY `FK_order_Insert_TO_Stock_1`;
ALTER TABLE `ServiceManagement` DROP FOREIGN KEY `FK_ShippingInfo_TO_ServiceManagement_1`;
ALTER TABLE `ServiceManagement` DROP FOREIGN KEY `FK_Courier_TO_ServiceManagement_1`;
ALTER TABLE `boxSize` DROP FOREIGN KEY `FK_ServiceManagement_TO_boxSize_1`;
ALTER TABLE `Customer` DROP FOREIGN KEY `FK_shoppingMall_TO_Customer_1`;
*/


CREATE TABLE `User` (
	`seller_id`	int	NOT NULL,
	`comp_reg_num`	int	NOT NULL,
	`comp_name`	Varchar(30)	NOT NULL,
	`user_id`	Varchar(8)	NOT NULL,
	`name`	char(5)	NOT NULL,
	`phone`	varchar(15)	NOT NULL,
	`password`	varchar(64)	NOT NULL,
	`email`	varchar(255)	NOT NULL,
	`addr1`	char(255)	NOT NULL,
	`addr2`	char(255)	NULL,
	`zipcode`	int	NOT NULL,
	`sign_up_path`	char(255)	NULL,
	`text_agree`	tinyint(1)	NOT NULL,
	`email_agree`	tinyint(1)	NOT NULL,
	`ad_agree`	tinyint(1)	NOT NULL,
	`status`	enum('deactivate', 'activate', 'banned', 'request')	NOT NULL	DEFAULT 'request',
	`reg_date`	datetime	NULL	DEFAULT current_timestamp
);

CREATE TABLE `Product` (
	`prodNo`	int	NOT NULL,
	`categoryNo`	int	NOT NULL,
	`brandNo`	int	NOT NULL,
	`prodName`	char(64)	NOT NULL,
	`item`	char(64)	NOT NULL,
	`prodCategory`	char(64)	NULL,
	`prodBrand`	char(64)	NULL,
	`salesPrice`	int	NOT NULL,
	`deliveryFee`	enum("유료","무료")	NOT NULL	DEFAULT "유료",
	`prodImg`	blob	NOT NULL,
	`prodDescription`	char(255)	NOT NULL,
	`reg_date`	datetime	NOT NULL,
	`salesState`	char(64)	NOT NULL,
	`stockQuantity`	int	NULL,
	`isProdDisplay`	tinyint(1)	NOT NULL
);

CREATE TABLE `Warehouse` (
	`warehouseCode`	INT	NOT NULL,
	`classification`	char(20)	NULL,
	`detailClassification`	char(20)	NULL,
	`warehouseName`	char(64)	NULL,
	`warehouseAddr`	char(255)	NULL,
	`warehouseRegistDate`	datetime	NULL,
	`managerPhone`	varchar(15)	NULL,
	`warehouseNo`	INT	NULL
);

CREATE TABLE `Orders` (
	`id` int not null,
	`OrderId`	VARCHAR(64)	NOT NULL,
	`shopId`	varchar(64)	NOT NULL,
	`seller_id`	int	NOT NULL,
	`OrderDate`	DATE	NOT NULL,
	`OrderQuantity`	INT	NOT NULL,
	`buyer`	char(10)	NOT NULL,
	`receiver`	char(10)	NOT NULL,
	`RecipientPhone`	VARCHAR(15)	NULL,
	`UnitPrice`	INT	NOT NULL,
	`SalesAmount`	INT	NOT NULL,
	`Payment`	INT	NOT NULL,
	`CourierName`	CHAR(64)	NOT NULL,
	`trackingInfo`	varchar(26)	NOT NULL,
	`tracking_flag`	tinyint(1)	NULL	DEFAULT 0	COMMENT '추후 송장 오배송 체크를 위한 콜롬. 보류.
0 :  성공
1: 실패',
	`prodNo`	int	NOT NULL,
	`warehouseCode`	int	NOT NULL,
	`brandNo`	int	NOT NULL,
	`ErrorId`	INT	NOT NULL,
	`DeliveryCategoryId`	INT	NOT NULL,
	`OrderStatusId`	INT	NOT NULL
);

CREATE TABLE `Category` (
	`categoryNo`	int	NOT NULL,
	`parent_ categoryNo`	int	NOT NULL,
	`categoryLevel`	int	NOT NULL,
	`categoryName`	char(64)	NOT NULL,
	`reg_date`	datetime	NOT NULL
);

CREATE TABLE `Brand` (
	`brandNo`	int	NOT NULL,
	`brandName`	char(64)	NOT NULL,
	`reg_date`	datetime	NOT NULL,
	`codeTypeNo`	int	NOT NULL
);

CREATE TABLE `TrackingNumber` (
	`tracking_id`	int	NOT NULL,
	`CourierID`	INT	NOT NULL,
	`label_type`	char(64)	NOT NULL,
	`a4_type`	char(64)	NULL
);

CREATE TABLE `ShippingInfo` (
	`shipping_id`	int	NOT NULL,
	`seller_id`	int	NOT NULL,
	`deliveryStatus`	tinyint(1)	NULL	DEFAULT 0	COMMENT '0: 배송
1 : 배송없음',
	`fulfillment`	tinyint(1)	NULL	DEFAULT 0	COMMENT '0: 설정안함
1: 설정함',
	`deliveryComp`	char(64)	NOT NULL,
	`deliveryOpt`	char(64)	NULL	COMMENT '택배/소포/등기, 직접배송(화물), 방문수령(판매자주소록필요), 퀵서비스(가능지역선택)',
	`sellerAddr_id`	int	NULL	COMMENT '배송방법 방문수령시 판매자조소록 필수',
	`quickService_id`	int	NULL,
	`reg_date`	datetime	NULL	DEFAULT current_timestamp
);

CREATE TABLE `CommonCode` (
	`codeNo`	int	NOT NULL,
	`codeTypeNo`	int	NOT NULL,
	`codeName`	char(64)	NOT NULL
);

CREATE TABLE `shoppingMall` (
	`id` int not null,
	`shopId`	varchar(64)	NOT NULL,
	`seller_id`	int	NOT NULL,
	`storeName`	char(64)	NOT NULL,
	`status`	enum('정상','사용중지')	NOT NULL	DEFAULT '정상',
	`mall_url`	varchar(255)	NULL,
	`reg_date`	datetime	NULL	DEFAULT current_timestamp
);

CREATE TABLE `Courier` (
	`CourierID`	INT	NOT NULL,
	`CourierName`	VARCHAR(255)	NOT NULL,
	`contractNumber`	long	NOT NULL	COMMENT '8 ~ 10자리 수',
	`courierCode`	varchar(64)	NOT NULL	COMMENT 'https://developers.coupangcorp.com/hc/ko/articles/360034156033-%ED%83%9D%EB%B0%B0%EC%82%AC-%EC%BD%94%EB%93%9C'
);

CREATE TABLE `order_Insert` (
	`insertCode`	int	NOT NULL,
	`stockNo`	INT	NOT NULL,
	`prodNo2`	int	NOT NULL,
	`preoCode`	int	NOT NULL,
	`insertDate`	DATE	NULL,
	`customer`	char(30)	NULL,
	`insertPersonnel`	char(30)	NULL,
	`prodName`	char(64)	NULL,
	`preoDate`	DATE	NULL,
	`insertQuantity`	int	NULL,
	`insertUnitPrice`	int	NULL,
	`insertPrice`	int	NULL,
	`stockQuantity`	int	NULL,
	`insertconfirm`	tinyint	NULL
);

CREATE TABLE `ShoppingMallList` (
	`seller_id`	int	NOT NULL,
	`shopId`	varchar(255)	NOT NULL,
	`shoppingMall`	char(64)	NOT NULL,
	`form`	char(64)	NOT NULL,
	`launchingStatus`	tinyint(1)	NULL	DEFAULT 0	COMMENT '0: 미입점
1: 입점'
);

CREATE TABLE `order_shipping` (
	`CourierID`	INT	NOT NULL  	,
	`OrderId`	VARCHAR(50)	NOT NULL,
	`shopId`	varchar(64)	NOT NULL,
	`seller_id`	int	NOT NULL
);

CREATE TABLE `Stock` (
	`stockNo`	int	NOT NULL,
	`prodNo`	int	NOT NULL,
	`insertCode`	int	NOT NULL,
	`warehouseCode`	int	NOT NULL,
	`prodName`	char(64)	NULL,
	`stockQuantity`	int	NULL,
	`warehouseName`	char(64)	NULL,
	`warehouseAddr`	char(255)	NULL,
	`salePrice`	int	NULL,
	`brandNo`	int	NOT NULL,
	`categoryNo`	int	NOT NULL
);

CREATE TABLE `ServiceManagement` (
	`service_id`	int	NOT NULL	COMMENT '발송지정보에 발송지 전화번호는 판매자 번호를 가지고 오면 됨',
	`shipping_id`	int	NOT NULL	COMMENT '기준정보: 연동판매자코드(회사코드), 사업자번호 가져와야댐',
	`CourierID`	INT	NOT NULL,
	`Field`	VARCHAR(255)	NULL
);

CREATE TABLE `order_takeout` (
	`takeoutCode`	int	NOT NULL,
	`stockNo`	int	NOT NULL,
	`prodNo`	int	NOT NULL,
	`warehouseCode`	INT	NOT NULL,
	`OrderId`	VARCHAR(64)	NOT NULL,
	`takeoutDate`	DATE	NULL,
	`warehouserName`	int	NULL,
	`prodName`	char(64)	NULL,
	`takeoutState`	char(64)	NULL,
	`takeoutconfirm`	tinyint(1)	NULL,
	`takeoutpersonnel`	char(10)	NULL,
	`takeoutQuantity`	int	NULL,
	`takeoutUnitPrice`	int	NULL,
	`takeoutPrice`	int	NULL
);

CREATE TABLE `boxSize` (
	`box_id`	int	NOT NULL,
	`CourierID`	INT	NOT NULL,
	`size`	char(2)	NOT NULL,
	`prepay`	int	NOT NULL	DEFAULT 0,
	`credit`	int	NOT NULL	DEFAULT 0,
	`cashOnDelivery`	int	NOT NULL	DEFAULT 0,
	`return`	int	NOT NULL	DEFAULT 0
);

CREATE TABLE `preOrder` (
	`preoCode`	int	NOT NULL,
	`warehouseCode`	int	NOT NULL,
	`prodNo`	int	NOT NULL,
	`stockNo`	int	NOT NULL,
	`preoDate`	datetime	NULL,
	`customer`	char(64)	NULL,
	`preoState`	char(64)	NULL,
	`prodName`	char(64)	NULL,
	`warehaouseName`	char(64)	NULL,
	`stockQuantity`	int	NULL,
	`preoQuantity`	int	NULL,
	`preoUnitPrice`	int	NULL,
	`preoPrice`	int	NULL,
	`preoconfirm`	tinyint	NULL
);

CREATE TABLE `CommonCodeType` (
	`codeTypeNo`	int	NOT NULL,
	`codeTypeName`	char(64)	NULL
);

CREATE TABLE `Waybill` (
	`waybill_id`	int	NOT NULL,
	`OrderId`	VARCHAR(64)	NOT NULL,
	`CourierID`	INT	NOT NULL,
	`tracking_id`	int	NOT NULL
);

CREATE TABLE `Customer` (
	`customer_id`	int	NOT NULL,
	`shopId`	varchar(255)	NOT NULL,
	`user_id`	Varchar(8)	NOT NULL,
	`name`	char(5)	NOT NULL,
	`phone`	varchar(15)	NOT NULL,
	`password`	varchar(64)	NOT NULL,
	`email`	varchar(255)	NOT NULL,
	`addr1`	char(255)	NOT NULL,
	`addr2`	char(255)	NULL,
	`zipcode`	int	NOT NULL,
	`sign_up_path`	char(255)	NULL,
	`text_agree`	tinyint(1)	NOT NULL,
	`email_agree`	tinyint(1)	NOT NULL,
	`ad_agree`	tinyint(1)	NOT NULL,
	`status`	enum('deactivate', 'activate', 'banned', 'request')	NOT NULL	DEFAULT 'request',
	`reg_date`	datetime	NULL	DEFAULT current_timestamp
);

CREATE TABLE `OrderConfirmError` (
	`ErrorId`	INT	NOT NULL,
	`ErrorReason`	TEXT	NOT NULL
);

CREATE TABLE `DeliveryCategory` (
	`DeliveryCategoryId`	INT	NOT NULL,
	`DeliveryClassification`	CHAR(2)	NOT NULL
);

CREATE TABLE `OrderStatus` (
	`OrderStatusId`	INT	NOT NULL,
	`OrderStatusType`	VARCHAR(20)	NOT NULL
);

ALTER TABLE `User` ADD CONSTRAINT `PK_USER` PRIMARY KEY (
	`seller_id`
);

ALTER TABLE `Product` ADD CONSTRAINT `PK_PRODUCT` PRIMARY KEY (
	`prodNo`
);

ALTER TABLE `Warehouse` ADD CONSTRAINT `PK_WAREHOUSE` PRIMARY KEY (
	`warehouseCode`
);

ALTER TABLE `Orders` ADD CONSTRAINT `PK_ORDERS` PRIMARY KEY (
	`OrderId`,
	`shopId`,
	`seller_id`
);

ALTER TABLE `Category` ADD CONSTRAINT `PK_CATEGORY` PRIMARY KEY (
	`categoryNo`
);

ALTER TABLE `Brand` ADD CONSTRAINT `PK_BRAND` PRIMARY KEY (
	`brandNo`
);

ALTER TABLE `TrackingNumber` ADD CONSTRAINT `PK_TRACKINGNUMBER` PRIMARY KEY (
	`tracking_id`,
	`CourierID`
);

ALTER TABLE `ShippingInfo` ADD CONSTRAINT `PK_SHIPPINGINFO` PRIMARY KEY (
	`shipping_id`
);

ALTER TABLE `CommonCode` ADD CONSTRAINT `PK_COMMONCODE` PRIMARY KEY (
	`codeNo`,
	`codeTypeNo`
);

ALTER TABLE `shoppingMall` ADD CONSTRAINT `PK_SHOPPINGMALL` PRIMARY KEY (
	`shopId`,
	`seller_id`
);

ALTER TABLE `Courier` ADD CONSTRAINT `PK_COURIER` PRIMARY KEY (
	`CourierID`
);

ALTER TABLE `order_Insert` ADD CONSTRAINT `PK_ORDER_INSERT` PRIMARY KEY (
	`insertCode`
);

ALTER TABLE `Stock` ADD CONSTRAINT `PK_STOCK` PRIMARY KEY (
	`stockNo`,
	`prodNo`,
	`insertCode`
);

ALTER TABLE `ServiceManagement` ADD CONSTRAINT `PK_SERVICEMANAGEMENT` PRIMARY KEY (
	`service_id`,
	`shipping_id`,
	`CourierID`
);

ALTER TABLE `order_takeout` ADD CONSTRAINT `PK_ORDER_TAKEOUT` PRIMARY KEY (
	`takeoutCode`
);

ALTER TABLE `boxSize` ADD CONSTRAINT `PK_BOXSIZE` PRIMARY KEY (
	`box_id`,
	`CourierID`
);

ALTER TABLE `preOrder` ADD CONSTRAINT `PK_PREORDER` PRIMARY KEY (
	`preoCode`
);

ALTER TABLE `CommonCodeType` ADD CONSTRAINT `PK_COMMONCODETYPE` PRIMARY KEY (
	`codeTypeNo`
);

ALTER TABLE `Waybill` ADD CONSTRAINT `PK_WAYBILL` PRIMARY KEY (
	`waybill_id`
);

ALTER TABLE `Customer` ADD CONSTRAINT `PK_CUSTOMER` PRIMARY KEY (
	`customer_id`,
	`shopId`
);

ALTER TABLE `OrderConfirmError` ADD CONSTRAINT `PK_ORDERCONFIRMERROR` PRIMARY KEY (
	`ErrorId`
);

ALTER TABLE `DeliveryCategory` ADD CONSTRAINT `PK_DELIVERYCATEGORY` PRIMARY KEY (
	`DeliveryCategoryId`
);

ALTER TABLE `OrderStatus` ADD CONSTRAINT `PK_ORDERSTATUS` PRIMARY KEY (
	`OrderStatusId`
);

CREATE INDEX idx_seller_id ON shoppingMall (seller_id);
ALTER TABLE `Orders` ADD CONSTRAINT `FK_shoppingMall_TO_Orders_1` FOREIGN KEY (
	`shopId`
)
REFERENCES `shoppingMall` (
	`shopId`
);

ALTER TABLE `Orders` ADD CONSTRAINT `FK_shoppingMall_TO_Orders_2` FOREIGN KEY (
	`seller_id`
)
REFERENCES `shoppingMall` (
	`seller_id`
);

ALTER TABLE `TrackingNumber` ADD CONSTRAINT `FK_Courier_TO_TrackingNumber_1` FOREIGN KEY (
	`CourierID`
)
REFERENCES `Courier` (
	`CourierID`
);

ALTER TABLE `CommonCode` ADD CONSTRAINT `FK_CommonCodeType_TO_CommonCode_1` FOREIGN KEY (
	`codeTypeNo`
)
REFERENCES `CommonCodeType` (
	`codeTypeNo`
);

ALTER TABLE `shoppingMall` ADD CONSTRAINT `FK_User_TO_shoppingMall_1` FOREIGN KEY (
	`seller_id`
)
REFERENCES `User` (
	`seller_id`
);

ALTER TABLE `Stock` ADD CONSTRAINT `FK_Product_TO_Stock_1` FOREIGN KEY (
	`prodNo`
)
REFERENCES `Product` (
	`prodNo`
);

ALTER TABLE `Stock` ADD CONSTRAINT `FK_order_Insert_TO_Stock_1` FOREIGN KEY (
	`insertCode`
)
REFERENCES `order_Insert` (
	`insertCode`
);

ALTER TABLE `ServiceManagement` ADD CONSTRAINT `FK_ShippingInfo_TO_ServiceManagement_1` FOREIGN KEY (
	`shipping_id`
)
REFERENCES `ShippingInfo` (
	`shipping_id`
);

ALTER TABLE `ServiceManagement` ADD CONSTRAINT `FK_Courier_TO_ServiceManagement_1` FOREIGN KEY (
	`CourierID`
)
REFERENCES `Courier` (
	`CourierID`
);

ALTER TABLE `boxSize` ADD CONSTRAINT `FK_ServiceManagement_TO_boxSize_1` FOREIGN KEY (
	`CourierID`
)
REFERENCES `ServiceManagement` (
	`CourierID`
);

ALTER TABLE `Customer` ADD CONSTRAINT `FK_shoppingMall_TO_Customer_1` FOREIGN KEY (
	`shopId`
)
REFERENCES `shoppingMall` (
	`shopId`
);

