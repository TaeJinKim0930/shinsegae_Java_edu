public interface MyService {

    public void myServiceMethod();
}
