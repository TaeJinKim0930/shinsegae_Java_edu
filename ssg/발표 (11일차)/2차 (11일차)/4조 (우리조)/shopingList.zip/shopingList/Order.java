package oop.day3.shopingList;

/**
 * User 의 값과 Book 의 값을 보관하는 클래스 입니다만 사용되지 않았습니다..
 */
public class Order {
    User[] user;
    Book[] book;


    Order() {}

    Order(User[] user, Book[] book) {
        this.user = user;
        this.book = book;
    }

    public Book[] deleteShoppingList(Book[] book) {
        return book = new Book[30];
    }

}
