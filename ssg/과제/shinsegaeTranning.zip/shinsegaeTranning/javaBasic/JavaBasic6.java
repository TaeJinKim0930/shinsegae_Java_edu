package shinsegaeTranning.javaBasic;

public class JavaBasic6 {
    public static void main(String[] args) {
        int starLength = 1;

        // 가로 5줄
        for (int i = 5; i > 0; i--) {
            /**
             *      ----------
             *      |x x x   |
             *      |x x    |
             *      |x      |
             *      ---------
             *      이부분을 공백으로 출력
             */
            for (int j = 0; j < i; j++) {
                System.out.print(" ");
            }
            // 공백값이 있으니 그냥 별을 출력하면 원하는 위치에 출력 가능
            for (int j = 0; j < starLength; j++) {
                System.out.print("*");

            }
            // 줄을 바꿀때 마다 별의 갯수가 늘어나기 때문에 startLength++ 을 해주면서 위에 있는 for loop 의 최대값을 늘려줌
            starLength++;
            // 가로 줄 바꿈
            System.out.println();
        }
    }
}
