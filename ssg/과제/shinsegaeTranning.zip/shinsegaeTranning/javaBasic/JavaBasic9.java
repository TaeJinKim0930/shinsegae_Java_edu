package shinsegaeTranning.javaBasic;

import javax.swing.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.IntStream;

import static java.lang.Integer.MIN_VALUE;
import static java.lang.Integer.TYPE;

public class JavaBasic9 {


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        List<Integer> score = new ArrayList<>();

        // 학생수를 글로벌 값으로 받아주기. -1 값을 디폴트로 해놓아서 중복 될 일 없게
        int numOfStu = -1;

        while (true) {
            System.out.println("-----------------------------------");
            System.out.println("1. 학생수 | 2. 점수입력 | 3. 점수리스트 | 4. 분석 | 5. 종료 ");
            System.out.println("-----------------------------------");
            // 스위치에서 받아주는 선택 값
            int choice = in.nextInt();

            switch (choice) {
                // 만약 선택값이 1 이라면,
                case 1 -> {
                    try {
                        System.out.printf("선택> %d\n", choice);
                        System.out.print("학생수>");
                        // 학생 수를 받기
                        numOfStu = in.nextInt();
                    } catch(InputMismatchException err) {
                        System.out.println(err + ": 숫자를 입력해 주세요 ");
                    }
                }
                case 2 -> {

                    try {
                        System.out.printf("선택> %d\n", choice);
                        // 학생 수 만큼 for loop
                        for (int i = 0; i < numOfStu; i++) {
                            System.out.printf("scores[%d]> ", i);
                            // 여기서 받는 값들을 arrayList 에 넣어주기
                            score.add(in.nextInt());
                        }
                    } catch(InputMismatchException err) {
                        System.out.println(err + ": 숫자를 입력해 주세요 ");
                    }
                }
                case 3 -> {
                    try {
                        System.out.printf("선택> %d\n", choice);
                        for (int i = 0; i < score.size(); i++) {
                            // arrayList 는 arr[0] 대신 arr.get(i) 를 씁니다.
                            System.out.printf("scores[%d]: %d\n", i, score.get(i));
                        }
                    } catch(InputMismatchException err) {
                        System.out.println(err + ": 숫자를 입력해 주세요 ");
                    }
                }
                case 4 -> {

                    try {
                        System.out.printf("선택> %d\n", choice);
                        // stream 을 사용한 score 에서 최대값을 찾아줍니다. orElse 는 만약에 arrayList 에 값이 없다면
                        // 0(주어진) 값을 출력하고 있으면 그 값을 출력합니다
                        int max = score.stream().max(Integer::compareTo).orElse(0);
                        System.out.println("최고 점수: " + max);

                        // Stream 을 사용해 평균을 구합니다.
                        double avg = score.stream().mapToDouble(Integer::intValue).average().orElse(0.0);
                        // 소수점 두자리수를 뽑아내기 위해서 DecimalFormat 을 사용했는데 #.# 을 사용하면 7.0 일때 7의 값으로 돌아오고
                        // #.0 으로 하면 소수점이 0이여도 0이 출력 됩니다
                        DecimalFormat df = new DecimalFormat("#.0");
                        // 위에 만들어준 format 을 avg 값에 입힙니다.
                        System.out.println("평균 점수: " + df.format(avg));
                    } catch(InputMismatchException err) {
                        System.out.println(err + ": 숫자를 입력해 주세요 ");
                    }

                }
                case 5 -> {
                    System.out.printf("선택> %d\n", choice);
                    System.out.println("프로그램 종료");
                    System.exit(0);
                }
            }
        }
    }
}
