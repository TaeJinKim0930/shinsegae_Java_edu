package shinsegaeTranning.javaBasic;

/**
 *  For문을 이용하여 아래 그림과 같은 실행 결과가 나오는 코드를 작성하세요.
 */
public class JavaBasic5 {
    public static void main(String[] args) {
        // 세로 5줄을 출력
        for (int i = 0; i <= 5; i++) {
            // 가로줄에 * 출력
            for (int j = 0; j < i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
