package shinsegaeTranning.javaBasic;

public class JavaBasic7 {
    public static void main(String[] args) {
        int space = 3;
        int firstSpace = space;
        int secondSpace = space;
        int at = 3; // @

        // 가로 5줄
        for (int i = 1; i <= 5; i++) {
            /**
             *      ----------
             *      |x x x   |
             *      |x x    |
             *      |x      |
             *      ---------
             *      이부분을 공백으로 출력
             */
            for (int j = 0; j <= firstSpace; j++) {
                System.out.print(" ");
            }
            firstSpace--;

            // @ 출력
            for (int j = 0; j < i; j++) {
                System.out.print("@");
            }
            // ++ 해주는 이유는 한줄마다 @ 가 두개가 늘어나기 때문에 @ 출력 for loop 최대값을 늘려줌
            i++;
            System.out.println();
        }

        // 4번째줄 5번째줄 출력
        for (int i = 1; i <= 3; i++) {
            for (int j = secondSpace; j > 0 ; j--) {
                System.out.print(" ");
            }
            secondSpace++;
            for (int j = 0; j < at; j++) {
                System.out.print("@");
            }
            at -= 2;
            i++;
            System.out.println();
        }
    }
}
