package shinsegaeTranning.javaBasic;

/**
 * While문과 Math.random() 메소드를 이용해서 두개의 주사위를 던졌을때
 * 나오는 숫자를(숫자1, 숫자2) 형태로 출력하고,
 * 숫자의 합이 5가 아니면 계속 주사위를 던지고,
 * 숫자의 합이 5이면 실행을 멈추는 코드를 작성하세요.
 * 숫자의 합이 5가 되는 경우의 수를 생각하세요.
 */
public class JavaBasic3 {
    public static void main(String[] args) {

        while (true) {
            // 두개의 주사위
            int firstDice = (int)(Math.random() * (6 - 1) + 1);
            int secondDice = (int)(Math.random()* (6 - 1) + 1);
            System.out.println("주사위의 숫자: " + firstDice + ", " + secondDice);

            // 주사위의 합이 5일 경우 그만
            if (firstDice + secondDice == 5) {
                break;
            }
        }

        // 주사위 숫자: 1 ~ 6
        for (int i = 1; i <= 6; i++) {
            for (int j = 1; j <= 6; j++) {
                // 숫자의 합이 5가 되는 경우의 수
                if ( i + j == 5) {
                    System.out.println("5를 만들 수 있는 경우의 수: " + i + " " + j);
                }
            }
        }
    }
}