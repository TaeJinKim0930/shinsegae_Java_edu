package shinsegaeTranning.javaBasic;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * 8. While문 Scanner 클래스의 nextLine() 이용하여 클래스명: JavaBasic8
 * 키보드로 부터 입력된 데이터로 예금, 출금, 조회, 종료 기능을
 * 제공하는 코드를 작성하세요
 */
public class JavaBasic8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int deposit = 0;
        int withdraw = 0;
        int balance = 0;

        while(true) {
            System.out.println("-----------------------------------");
            System.out.println("1. 예금 | 2. 출금 | 3. 잔고 | 4. 종료 ");
            System.out.println("-----------------------------------");
            int choice = in.nextInt();

            switch(choice) {
                case 1 -> {
                    // deposit(예금)을 받고 잔고에 더해주기
                    // try catch 로 숫자 외에 값이 들어올시 에러 문구 출력
                    try {
                        System.out.printf("선택> %d\n", choice);
                        System.out.print("예금액>");
                        deposit = in.nextInt();
                        balance += deposit;
                        System.out.println();
                    } catch(InputMismatchException err) {
                        System.out.println(err + ": 숫자를 입력해 주세요 ");
                    }
                }
                case 2 -> {
                    // withdraw(출금)을 받고 잔고에 더해주기
                    // 출금 금액이 잔고보다 많을 시 에러문구 출력 하고 continue 로 while 반복문 처음부터 다시 재생
                    // try catch 로 숫자 외에 값이 들어올시 에러 문구 출력
                    try {
                        System.out.printf("선택> %d\n", choice);
                        System.out.print("출금액>");
                        withdraw = in.nextInt();
                        if (withdraw > balance) {
                            System.out.println("출금액이 잔고보다 많습니다. 다시 시도해주세요");
                            continue;
                        } else {
                            balance -= withdraw;
                            System.out.println();
                        }
                    } catch(InputMismatchException err) {
                        System.out.println(err + ": 숫자를 입력해 주세요 ");
                    }
                }
                case 3 -> {
                    System.out.printf("선택> %d\n", choice);
                    System.out.printf("잔고>%d\n", balance);
                }
                case 4 -> {
                    System.out.printf("선택> %d\n", choice);
                    System.out.printf("\n\n프로그램 종료");
                    System.exit(0);
                }
            }
        }
    }
}
