package shinsegaeTranning.javaBasic;

/**
 *  중첩 for문을 이용하여 방정식 4x + 5y = 60 의 모든 해를 구하여 (x,y) 형태로
 * 출력하는 코드를 작성하세요. 단, x와 y는 10이하의 자연수
 */
public class JavaBasic4 {
    public static void main(String[] args) {
        // 4x + 5y = 60
        for (int x = 1; x <= 10; x++) {
            for (int y = 1; y <= 10; y++) {
                /**
                 * 수학 식 처럼 똑같이 적었는데 nested for loop 을 쓰면
                 * x = 1, y = 1 ~ 10
                 * x = 2, y = 1 ~ 10
                 * x = 3, y = 1 ~ 3
                 * ...
                 * 하면서 모든 경우의 수 (10x10) 을 다 확인 할 수 있습니다.
                 */
                if ( ((4 * x) + (5 * y)) == 60) {
                    System.out.println(x + " " + y);
                }
            }
        }
    }
}
