package shinsegaeTranning.javaBasic;

/**
 * switch case 를 lambda 로 바꾸는건 "case 1 :" 을 "case 1 ->" 로 바꾸면 됩니다
 */
public class JavaBasic1 {
    public static void main(String[] args) {
        String grade = "B";

        int score1 = 0;
        switch (grade) {
            case "A" -> {
                score1 = 100;
                break;
            }
            case "B" -> {
                int result = 100 - 20;
                score1 = result;
                break;
            }
            default ->  score1 = 60;
        }

    }
}
