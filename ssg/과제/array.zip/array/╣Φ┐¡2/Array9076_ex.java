package array.배열2;


/**
 * fibonacci sequence
 */
public class Array9076_ex {
    public static void main(String[] args) {
        int n = 10; // chagne n to other numbers
        int a = 0, b = 1, c;
        if (n == 0) System.out.println(a);
        for (int i = 2; i <= n; i++) {
            c = a + b; // a0 + b1 = c1
            a = b; // a2 = b2
            b = c; // b1 = c1
            // a0 b1 c0 ==> c1, a2, b1
        }
        System.out.println(b);
    }
}
