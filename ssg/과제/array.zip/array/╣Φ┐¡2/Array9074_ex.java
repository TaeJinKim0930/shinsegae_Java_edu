package array.배열2;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

/**
 * 1부터 10까지의 정수를 입력받다가 입력된 정수가 범위를 벗어나면
 * 그 때까지 1번 이상 입력된 각 숫자의 개수를 작은 수부터 출력하는 프로그램을 작성하시오. (frequency)
 */
public class Array9074_ex {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        HashMap<Integer, Integer> map = new HashMap<>();

        /**
         * 만약에 map 안에 유저가 입력한 숫자가 없다면 그 key 값에 "숫자" 를 넣어주고 value 값에 1 을 넣어 줍니다
         * 만약에 입력한 숫자가 있다면 해당 숫자의 value 값을 + 1 해줍니다.
         * 그 후 map 을 돌면서 전체적으로 출력을 합니다
         */
        try {
            while (true) {
                if (in.hasNextInt()) {
                    int n = in.nextInt();
                    if (n <= 0 || n > 10) {
                        break;
                    } else {
                        if (!map.containsKey(n)) {
                            map.put(n, 1);
                        } else {
                            map.put(n, map.get(n) + 1); // +=
                        }
                    }
                }
            }
            map.forEach((key, value) -> System.out.printf("%d : %d개\n", key, value));
            in.close();
        } catch (Exception e) {
            System.out.println(e);
        }


    }
}
