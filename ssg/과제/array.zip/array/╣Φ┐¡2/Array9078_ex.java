package array.배열2;

import java.util.Arrays;
import java.util.Scanner;

/**
 * 3행 3열의 배열 두 개를 만들어서 입력을 받고 두 배열의 합을 구하여 출력하는 프로그램을 작성하시오.
 */
public class Array9078_ex {
    public static void main(String[] args) {
        Scanner in  = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
        String temp = in.nextLine();
        sb.append(temp.substring(11));

        int sum = 0;

        System.out.println(sum);
    }
}
