package array.배열2;

import java.util.HashMap;
import java.util.Scanner;

/**
 * 정수를 입력받다가 0이 입력되면 마지막에 입력된 0을 제외하고
 * 그 때까지 입력된 정수의 일의 자리 숫자가 각각 몇 개인지
 * 작은 수부터 출력하는 프로그램을 작성하시오. (0개인 숫자는 출력하지 않는다.)
 */
public class Array9075_ex {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        HashMap<Integer, Integer> hm = new HashMap<>();

        while(true) {
            int temp = in.nextInt();
            int temp2 = temp % 10;
            if(temp == 0) {
                break;
            } else{
                hm.put(temp2, hm.containsKey(temp2) ? hm.get(temp2) + 1 : 1);
            }
        }
        hm.forEach((key, value) -> System.out.println(key + " : " + value + "개"));

    }
}
