package array.배열2;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * 3행 3열의 배열을 선언하고 아래의 출력 예와 같이 초기화한 후 출력하는 프로그램을 작성하시오.
 */
public class Array9077_ex {
    public static void main(String[] args) {
        int[][] arr = {{3,5,4}, {2,6,7}, {8,10,1}};
        Arrays.stream(arr)
                .map(row -> Arrays.stream(row)
                        .mapToObj(String::valueOf)
                        .collect(Collectors.joining(" ")))
                .forEach(System.out::println);
    }
}
