package array.배열1;


import java.util.Arrays;

/**
 * 5개의 정수를 {95, 75, 85, 100, 50}로 초기화하고
 * 오름차순으로 정렬하여 출력하는 프로그램을 작성하시오.
 */
public class Array9073_ex {
    public static void main(String[] args) {
        int[] num = { 50, 75, 85, 95, 100 };

        // sort array ascending order
        Arrays.parallelSort(num);
        // print out the sorted array using lambda and foreach
        Arrays.stream(num)
                .forEach(i -> System.out.print(i + " "));
    }
}
