package array.배열1;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.OptionalDouble;
import java.util.Scanner;
import java.util.stream.IntStream;

import static java.lang.Integer.MAX_VALUE;

/**
 * 10명의 컴퓨터 점수를 입력받아 배열에 저장하고
 * 총점과 평균을 구하여 출력하는 프로그램을 작성하시오.
 * (평균은 반올림하여 소수 첫째자리까지 출력한다.)
 */
public class Array9072_ex {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        // int 배열 값을 10개로 제한을 하고 입력값을 넣어줍니다.
        int[] num = IntStream
                .generate(in::nextInt)
                .limit(10)
                .toArray();

        // Arrays 를 사용하여 모든 값을 다 더해주고
        // .reduce(callback, fun) ==> callback(0) is initial value and stores value of sum
        int sum = Arrays.stream(num)
                .reduce(0, Integer::sum);

        /**
         * get average of integers in int array and returns as double value
         * average()
         *      Returns an OptionalDouble describing the arithmetic mean of elements of this stream,
         *      or an empty optional if this stream is empty. ==> no need to throw exception
         *      This is a special case of a reduction.
         */
        double avg1 = Arrays.stream(num)
                .average()
                .getAsDouble();

        /**
         * .getAsDouble will give warning: 'OptionalDouble.getAsDouble()' without 'isPresent()' check
         * so, in this case, program needs to throw exception in case stream is empty
         */
        // Arrays 를 사용하여 평균 값을 구해줍니다.
        OptionalDouble averageOptional = Arrays.stream(num).average();
        double avg = 0.0;
        // if stream contains value, get average
        if (averageOptional.isPresent()) {
            avg = averageOptional.getAsDouble();
        } else {
            // Handle the case when the stream is empty
            System.out.println("The array is empty");
        }

        /**
         * DecimalFormat("#.##) : 7.80 ==> 7.8
         * DecimalFormat("#.00) : 7.80 ==> 7.80
         */
        final DecimalFormat df = new DecimalFormat("#.0");
        System.out.println("총점 = " + sum);
        System.out.println("평균 = " + df.format(avg));
    }
}
