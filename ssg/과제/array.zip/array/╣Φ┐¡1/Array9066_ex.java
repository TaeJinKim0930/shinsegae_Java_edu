package array.배열1;

public class Array9066_ex {
    public static void main(String[] args) {
        char c = (char)90;
        System.out.println((int)'Z');
        char[] arr = new char[26];

        for (int i = 0; i <  26; i++) {
            arr[i] = (char)(c - i);
        }

        for (int j = 0; j < arr.length; j++) {
            System.out.print(arr[j] + " ");
        }
    }
}
