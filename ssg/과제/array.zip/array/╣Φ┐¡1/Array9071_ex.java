package array.배열1;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;

import static java.lang.Integer.MAX_VALUE;

public class Array9071_ex {


    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[] odd = IntStream
                .generate(()->Integer.MAX_VALUE)
                .limit(10)
                .toArray();

        int[] even = IntStream
                .generate(()->Integer.MIN_VALUE)
                .limit(10)
                .toArray();

        int j = 0;
        int k = 0;
        for (int i = 0; i < odd.length; i++) {
            int n = in.nextInt();
            if (n % 2 == 0) {
                even[j++] = n;
            } else if (n % 2 == 1 || n % 2 == -1) {
                odd[k++] = n;
            }
        }

        Arrays.parallelSort(odd);
        Arrays.parallelSort(even);

        System.out.println(odd[0] + " " + even[even.length -1 ]);
    }
}
