package array.배열1;

import java.util.Scanner;

public class Array9068_ex {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] arr = new int[100];
        for (int i = 0; i < 100; i++) {
            int temp = in.nextInt();
            if (temp == 0) break;
            if (i % 2 == 1) {
                System.out.print(temp + " ");
            }

        }

    }
}
