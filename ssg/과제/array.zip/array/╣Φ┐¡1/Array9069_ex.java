package array.배열1;

import java.util.Scanner;

public class Array9069_ex {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] arr = new int[100];
        for (int i = 0; i < 100; i++) {
            int year = in.nextInt();
            int month = in.nextInt();

            if (month == 0) break;
            else {
                System.out.println("YEAR = " + year);
                System.out.println("MONTH = " + month);
                int day = 0;
                if (month > 12) {
                    System.out.println("잘못 입력하였습니다.");
                }
                else if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
                    if (month == 2) {
                        day = 29;
                    }
                } else {
                    switch(month) {
                        case 1  : day = 31;
                        case 2  : day = 28;
                        case 3  : day = 31;
                        case 4  : day = 30;
                        case 5  : day = 31;
                        case 6  : day = 30;
                        case 7  : day = 31;
                        case 8  : day = 31;
                        case 9  : day = 30;
                        case 10 : day = 31;
                        case 11 : day = 30;
                        case 12 : day = 31;
                    }
                }

                System.out.printf("입력하신 달의 날 수는 %d일입니다.\n", day);
            }
        }

    }
}
