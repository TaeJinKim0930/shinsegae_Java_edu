<template>
  <div id="app">
    <h1 id="app-head1">TODO Application</h1>

    <div id="app-div-addinput">
      <!-- This will be the input box where user inputs new hobby -->
      <input id="app-div-addinput-inputBox" type="text" v-model="newHobby">
      <!-- creating event @click and connects the addHobby method below with "추가" button here -->
      <input id="app-div-addinput-addButton" type="button" value="추가" @click="addHobby">
    </div>

    <div id="app-div-radio">
      <!-- By grouping and have label, it create switch-Like case where only one radio button can be selected among 3 buttons -->
      <ul>
        <label>
          <!-- v-model parts connect radio button with status, @change part triggers event named handleRadioChange which updates status value -->
          <!-- because we are using $event.target.value, we have to set up the value in here to update the status. so if I change all to hihi, status will be hihi -->
          <input type="radio" value="all" v-model="status" @change="handleRadioChange"> 전체
        </label>
        <label>
          <input type="radio" value="notDone" v-model="status" @change="handleRadioChange"> 미완료
        </label>
        <label>
          <input type="radio" value="done" v-model="status" @change="handleRadioChange"> 완료
        </label>
      </ul>
    </div>

    <!-- <div id="hobby-list">
      <hobby-list id="hobbyListList" v-bind:hobbys="hobbys"></hobby-list>
    </div> -->

    <div id="hi">
      <!-- this is the connection part with Hobbyfilter that is passing the values to HobbyFiler.vue so that it can computed that value and return-->
      <!-- :hobbys="hobbys" ==> first hobbys is from parent data and second hobbys is props from child, and whole thing binds connection between two -->
      <hobby-filter id="hobby" :hobbys="hobbys" :status="status" @toggle-status="handleToggleStatus"></hobby-filter>
    </div>

    <!-- <hobby-filter id="hobby" v-if: ... -->

    <div id="delete-all">
      <button @click="emptyHobby"> 모두삭제 </button>
    </div>

  </div>
</template>




<script>
    /**
     * = Checkbox work flow =
     *  1. From HobbyFilter.vue,
     *    1-1. In script, set up the checkedHobbies object in data to bind and change status using checkbox
     *    1-2. bind checkbox with checkedHobbies object to change status depends on checked/unchecked
     *      1-2-1. provide hobby.name as argument so that empty checkedHobbies can automatically have key as name and value as boolean
     *    1-3. set @change event to update hobby's status using handlecheckbox(hobby) method
     *    1-4. To differenticate each checkbox's name to hanlde checkbox individually, set id with 'checkbox-'+hobby.name
     *      1-4-1. such as ==> checkbox-soccer, checkbox-golf, and etc.."
     *    1-5. In handleCheckbox(hobby) method, grab the value using hobby.name as store in "checkbox" to update status
     *      1-5-1. using name "toggle-status", alert parent that parent needs to update hobby.name's status by checking checkbox.checked? state
     *      1-5-2. *this.emit emits event to parent component so that parent cant update it's since child does not have authority to update parent's value 
     * 2. From App.vue,
     *    2-1. In <hobby-filter>, bind the toggle-status which I set up in HobbyFilter.vue -> handleCheckbox -> $emit -> toggle-status.
     *    2-2. when the event triggers in <hobby-filter>, handleCheckBox find the value to update and provide handleToggleStatus with updated value so that handleToggleStatus can update
     *    2-2-1. since handleToggleStatus received the hobby name to update with value of new status, iterate through hobbys that matches hobby name and stores in local hobby here.
     *    2-2-2. if hobby in handleToggleStatus is not empty(data is found), update it's status.
     *    
     */

// import hobbyList from "./components/HobbyList.vue";
import HobbyFilter from "./components/HobbyFilter.vue"; // importing HobbyFilter.vue using name HobbyFilter 

export default {
  name: "app",
  data() {
    return {
      hobbys: [
        {
          // this is the dummy hobby list value so that I can test it.
          name: "운동",
          status: "notDone",
        },
      ],
      // setting up the values that will be created 
      newHobby: '',
      defaultStatus: 'notDone',
      // setting the the status as all so that when page is up, "전체" is being selected so that user can see the whole list.
      status: "all"
    };
  },
  components: { // then, register HobbyFilter as local component inside of parent(App.vue) so that I can use in template
    // "hobby-list": hobbyList,
    "hobby-filter": HobbyFilter, // first part is where it's being used in template, and the second part has to matched with imported name above.
  },
  methods: {
    // inserting new hobby. it trims any space and check whether the value exists from user
    addHobby() {
      if (this.newHobby.trim() !== '') {
        // if there is data from user input, insert and create new hobby.
        // later, this part will be DB insertion so that hobby actually can be inserted.
        this.hobbys.push({ name: this.newHobby, status: this.defaultStatus });
        this.newHobby = '';
      }
      // if the input does not exist but user still wants to input hobby, error message will pop up.
      else {
        console.log("your hobby has no value. Please fix it.")
      }
    },
    // Method to handle radio button selection; updates current status to the raido button selected from user.
    handleRadioChange(event) {
      console.log("radio button : ", event.target.value);
      this.status = event.target.value;
    },
    // handles the custom event name 'toggle-status' that is set in HobbyFilter.vue in handleCheckBox method
    handleToggleStatus({ name, status }) {
      // Find the hobby by name and update its status
      const hobby = this.hobbys.find(hobby => hobby.name === name);
      // if there is matched hobby name within the checkbox for the hobby, update status.
      if (hobby) {
        hobby.status = status;
      }
    },
    // set the list with empty object to empty hobbys object.
    emptyHobby() {
      this.hobbys = [];
    },
    
  },
  
};


</script>



<style>
#html,
body {
  background-color: blue;
}

#hi {
  background-color: hotpink;
}
body {
  display: flex;
  justify-content: center;
  flex-direction: column;
  text-align: center;
  margin-left: 10px;
  margin-right: 10px;
}

#app {
  max-width: 700px;
  max-height: 500px;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 20px;
  margin-bottom: 20px;
  background-color: white;
}

#app-head1 {
  background-color: rgb(127, 255, 138);
  margin: 10px;
}

#app-div-addinput-addButton {}

#app-div-radio label {
  display: inline-block;
  margin-right: 10px;
  /* Adjust as needed */
}

#app-div-addinput {
  background-color: pink;

}



#app-div-radio {
  background-color: aqua;

}

#hobby-list {
  background-color: red;
  margin: 10px;
}



#delete-all {
  background-color: aqua;
}
</style>
