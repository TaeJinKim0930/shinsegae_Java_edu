<template>
    <div>
        <ul>
            <li v-for="hobby in hobbys" v-bind:key="hobby.name">
                {{ hobby.name }}
                {{ hobby.status }}
                <input type="checkbox" id="delete-hobby">
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: "hobbyList",
    props: ['hobbys'],
};
</script>
