<template>
    <div>
        <ul>
            <li v-for="hobby in filteredHobbies" :key="hobby.name">
                {{ hobby.name }}
                {{ hobby.status }}
                <!-- when check box is checked, it triggers @change event and call handleCheckBox to change the value of current hobby by providing as argument  -->
                <!-- giving the hobby.name in checkedHobbies object automatically create two-way binding between checkbox status and checkedHobbies object -->
                <input type="checkbox" :id="'checkbox-' + hobby.name" v-model="checkedHobbies[hobby.name]"
                    @change="handleCheckBox(hobby)">

                <button @click="deleteTheHobby(hobby)"> 삭제 </button>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: "hobbyFilter", // this name can be anything. it exist for debugging purpose, so it does not play any role in in interaction between parent and child
    // receiving specified data(hobbys and status) that I want to receive from parent(App.vue)
    props: ['hobbys', 'status'], // this is the actual connection part with parents.

    // Automatically filters passing down hobbys(list of hobby) from parent(App.vue) and then returns with new hobbys(hobby list) to parent
    // so that parent can have list of filtered hobby.
    computed: {
        filteredHobbies() {
            // console.log(this.status);
            if (this.status === "all") {
                return this.hobbys; // Return all hobbies if status is "all", and not filters anything
            } else {
                // console.log("others")
                // returns hobby that is matched with passed down hobby from parent. 
                // ex) if the status from selected radio button is "done", then returns with only status that is "done"
                return this.hobbys.filter(hobby => hobby.status === this.status);
            }
        }
    },
    data() {
        return {
            // checkedHobbies object that have name as value and boolean as key to handle changing status
            // the reason why checkedHobbies does not have name set up within defaukt value is
            // to not change the default value of checkbox. if I set the default value as name :true,
            // the checkbox always will be checked regardless of hobby's status' value.
            checkedHobbies: {}
        }
    },
    /**
     * watch is used to perform action or response to changes in data,
     * in other words, it allows you to observe changed to property 
     * and execute logic whenever any changed is being made.
     * 
     * In this case, watch is being used to monitor changes in 'status',
     * so that if any change is made, watch triggers and execute callback function
     * 
     */
    watch: {
        statusFunction(newValue) {
            console.log("New status:", newValue);
        },
    },

    methods: {
        // provides (App.vue -> handleToggleStatus) updated status with the hobby.name so that parent know which hobby to update 
        handleCheckBox(hobby) {
            // Cannot modify data directly from parent's hobby, so we need to set up $emit to modify value
            // to notify parent so that parent can update the component.
            // this.status = event.target.checked ? 'done' : 'notDone'; so this won't work

            // this line retrieves the checkbox element using getElementBtId for each hobby
            const checkbox = document.getElementById(`checkbox-${hobby.name}`);

            // grabs current hobby data that template is iterating through and check whether checkbox is checked or not
            // and change status according to the set value (done/notDone).
            // $emit : emits event to parent component so that parent can update it's value because child cannot update the value.
            this.$emit('toggle-status', { name: hobby.name, status: checkbox.checked ? 'done' : 'notDone' });
        },
        /**
         * Delete the hobby that I want.
         * 
         */
        deleteTheHobby(hobby) {
            if (hobby) {
                const index = this.hobbys.findIndex(h => h.name === hobby.name);
                /**
                 * index === -1 indicates the hobby is not found in hobby list
                 * in this case, if the hobby is found, delete the hobby
                 *  The splice : used to modify the contents of an array by removing or replacing existing elements and/or adding new elements in place.
                 */
                if (index !== -1) {
                    this.hobbys.splice(index, 1);
                }
            }
        },
    }





};
</script>
