package exception;

public interface ErrorModel {
    String getMessage();
    String getCode();
    int getStatus();
}
