package view;

import Menu.WarehouseMenu;
import controller.BrandController;
import controller.ProductController;
import service.OrderServiceImpl;
import service.PreorderServiceImpl;
import service.ShippingServiceImpl;
import service.WarehousingServiceImpl;
import view.PreorderMenu;
import view.ShippingMenu;
import view.WarehousingMenu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TotalMenu {
    BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
    PreorderServiceImpl pm = new PreorderServiceImpl();
    ShippingServiceImpl sm = new ShippingServiceImpl();
    WarehousingServiceImpl wm = new WarehousingServiceImpl();
    WarehouseMenu whm = new WarehouseMenu();
    BrandController bm = new BrandController();
    ProductController pcm = new ProductController();
    OrderServiceImpl om = new OrderServiceImpl();
    UserMenu userMenu = new UserMenu();

    public void selectMenu() {
        userMenu.mainMenu();
        try {
            while (true) {
                System.out.println("2.주문관리 | 3.상품관리 | 4.창고관리 | 5.입고관리 | 6.출고관리 | 7.발주관리");
                System.out.println("메뉴를 선택해주세요");
                int select = Integer.parseInt(bf.readLine());
                switch (select) {
                    case 1 :  userMenu.mainMenu(); break;
                    case 2 : om.mainMenu(); break;
                    case 3 : pcm.mainMenu(); break;
                    case 4 : whm.mainMenu(); break;
                    case 5 : wm.menuList(); break;
                    case 6 : sm.menuList(); break;
                    case 7 : pm.menuList(); break;
                    default : {
                        System.out.println("올바른 숫자를 입력하세요");
                        selectMenu();
                    }
                }

            }


        } catch (
                NumberFormatException n) {
            System.out.println("문자가 아닌 숫자만 입력하시오.");
            selectMenu();
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }
}
