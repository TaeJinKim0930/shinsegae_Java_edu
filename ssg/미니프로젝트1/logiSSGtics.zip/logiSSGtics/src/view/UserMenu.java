package view;

import config.UserManager;
import service.UserServiceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UserMenu {
    UserServiceImpl userService = new UserServiceImpl();
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public boolean mainMenu() {


        try {
            while (UserManager.getInstance().getCurUser() == null || UserManager.getInstance().getCurCustomer() == null) {
                // 유저가 로그인 완료
                if (UserManager.getInstance().getCurUser() != null || UserManager.getInstance().getCurCustomer() != null) {
                    // TODO::fix
//                    System.out.println("이미 로그인이 되어 있는 상태 입니다.");
//                    System.out.println("로그아웃 하시겠습니까? (Y/N)");
                    String yes = br.readLine();
                    if(yes.equals("Y")) {
                        UserManager.getInstance().logoutUser();
                        System.out.println(UserManager.getInstance().getCurUser() + " gh");
                    }
                    break;
                }
                // 구매자로 로그인할지 판매자로 할지
                // 판매자 1, 구매자 2
                System.out.println("=========================================================================");
                System.out.println("|| 1. 회원가입 | 2. 판매자 로그인 | 3. 구매자 로그인                          ||");
                System.out.println("=========================================================================");
                String choice = br.readLine();

                switch (choice) {
                    case "1" : {
                        registerMenu();
                        break;
                    }
                    case "2" : {
                        loginMenu(choice);
                        break;
                    }
                    case "3" : {
                        loginMenu(choice);
                        break;
                    }
                    default : {
                        System.out.println("잘못된 값입니다.");
                    }
                }

            }
            return true;
        } catch (Exception e) {
            System.out.println("문제");

        }
        return false;
    }

    public void registerMenu() throws IOException {
        System.out.println("=========================================================================");
        System.out.println("회원가입을 진행합니다.");
        System.out.println("유저아이디를 입력해주세요: ");
        String id = br.readLine();
        System.out.println("비밀번호를 입력해주세요");
        String password = br.readLine();
    }

    public boolean loginMenu(String choice) {
        try {
            System.out.print("로그인을 진행 할 아이디를 입력해주세요 : ");
            String user = br.readLine();

            System.out.print("로그인을 진행 할 비밀번호를 입력해주세요 : ");
            String pw = br.readLine();
            userService.userLogin(choice, user, pw);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


}
