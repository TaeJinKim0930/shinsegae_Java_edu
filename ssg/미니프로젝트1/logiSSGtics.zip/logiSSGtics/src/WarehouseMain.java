

import Menu.WarehouseMenu;

public class WarehouseMain {

    public static void main(String[] args) {
        WarehouseMenu whM = new WarehouseMenu();
        //WarehouseDao dao = new WarehouseDao();

        whM.mainMenu();
    }
}
