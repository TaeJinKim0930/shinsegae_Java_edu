public class SellPick {
    public static void main(String[] args) {

    }
}
