package service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

//public interface ShippingService {
//
//    public abstract void request();  // 출고 요청은 재고 테이블에서 상품코드, 상품명, 상품 수량,단가,금액을 가져와서 요청함
//    public abstract void ShippingDocument();
//    public abstract void ShippingList();
//    public abstract void confirm();
//    public abstract void serch ();
//    public abstract void authorize ();
//    public abstract void exit();
//}
