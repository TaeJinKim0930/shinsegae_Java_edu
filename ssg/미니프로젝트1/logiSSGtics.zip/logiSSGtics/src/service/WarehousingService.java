//package service;
//
//import java.io.IOException;
//import java.sql.SQLException;
//import java.text.ParseException;
//
//public interface WarehousingService {
//
//    public abstract void request() throws IOException, ParseException, SQLException;
//    public abstract void admincurrent();
//    public abstract void orderInsertDocument() throws SQLException, IOException, ParseException;
//    public abstract void orderInsertList() throws SQLException, IOException, ParseException;
//    public abstract void confirm();
//    public abstract void update () throws SQLException, IOException, ParseException;
//    public abstract void cancle () throws IOException, SQLException, ParseException;
//    public abstract void authorize ();
//    public abstract void assignPositon ();
//    public abstract void assignDate ();
//    public abstract void exit();
//}
