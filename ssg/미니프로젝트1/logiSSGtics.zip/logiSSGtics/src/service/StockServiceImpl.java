package service;

public class StockServiceImpl implements StockService{
    @Override
    public void get() {

    }
}
