package service;

import entity.Customer;
import model.UserRole;
import entity.User;
import exception.ErrorCodeList;
import exception.ExceptionOutput;
import config.UserManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserServiceImpl implements UserService {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    @Override
    public boolean isCompRegNumValid(int userId) {
        return false;
    }

    /**
     * 이메일 정규식에서 벗어난 형식이면 ENUM 파일에서 유효하지 않는 이메일 형식이라는 에러문구를 출력합니다.
     *
     * @param email : 유저가 입력한 이메일 값
     * @return true  : 이메일 형식일 경우
     * false : 이메일 형식이 아닐 경우
     */
    public boolean emailValidator(String email) {
        try {
            String regex = "^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@(?:\\w+\\.)+\\w+$";
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(email);
            if (!m.matches()) {
                // 유효하지 않는 이메일 형식입니다.
                throw new ExceptionOutput(ErrorCodeList.INVALID_INPUT_EMAIL);
            }
            return true;
        } catch (Exception e) {

            return false;
        }
    }

    /**
     * 핸드폰 정규식에서 벗어난 형식이면 ENUM 파일에서 유효하지 않는 핸드폰 형식이라는 에러문구를 출력합니다.
     *
     * @param phone : 유저가 입력한 핸드폰 값
     * @return true  : 핸드폰 형식일 경우
     * false : 핸드폰 형식이 아닐 경우
     * @throws : INVALID_INPUT_PHONENUMBER : 유효하지 않는 전화번호 형식입니다.
     * @author : Tae Jin Kim
     * @date : 2024-02-13
     */
    public boolean isValidPhoneNumber(String phone) {
        try {
            /**
             * == 첫 세자리 == ^01(?:0|1|[6-9])
             *      정규식 패턴을 01로 시작
             *      01 다음에 오는 값으로 0,1 또는 6~9 사이 값으로 지정
             *
             * == 두 번째 자리 == (\d{3}|\d{4})
             *     3자리 또는 4자리의 숫자를 허용 하는 것으로 지정
             *
             * == 세 번째 자리 == (\d{4})
             *      마지막은 4자리 숫자로 지정
             *
             * == 종료 == $
             *      종료를 알리는 $
             *
             * == 구분 값 [-] ==
             * . 또는 - 값이 없거나 단 한개만 존재 하는 것
             */
            String regex = "^010[-]\\d{3,4}[-]\\d{4}$";

            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(phone);

            if (!m.matches()) {
                // 유효하지 않는 전화번호 형식입니다..
                throw new ExceptionOutput(ErrorCodeList.INVALID_INPUT_PHONENUMBER);
            } else {
                System.out.println("사용가능한 전화번호 입니다!");
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 유저가 회원가입을 할 시 생성이 가능한 아이디인지 확인을 해주는 메소드 입니다.
     * <p>
     * userId 값은 공백 없이 영문+숫자 8자리 이하이여야 합니다.
     *
     * @param userID
     * @return true  : 유저가 입력한 아이디가 정규식에 맞음으로 생성이 가능합니다
     * false : 유저가 입력한 아이디가 생성이 불가능 합니다.
     * @throws : ID_CONTAINS_SPACE               : 아이디는 공백을 포함 할 수 없습니다
     *           ID_MAXIMUM_LENGTH_EXCCEDED      : 아이디가 8자를 초과하였습니다.
     *           ID_CONTAINS_NON_ALPHABET_NUMBER : 아이디는 영어와 숫자만 입력이 가능합니다.
     * @author
     * @date
     */
    public boolean isValidUserId(String userID) {
        try {
            String regex = ".*[^a-zA-Z0-9].*";
            // 아이디가 공백을 포함
            if (userID.contains(" ")) {
                throw new ExceptionOutput(ErrorCodeList.ID_CONTAINS_SPACE);
                // 아이디가 8자리 초과
            } else if (userID.length() > 8) {
                throw new ExceptionOutput(ErrorCodeList.ID_MAXIMUM_LENGTH_EXCCEDED);
                // 아이다가 영어와 숫자를 제외 한 값
            } else if (userID.matches(regex)) {
                throw new ExceptionOutput((ErrorCodeList.ID_CONTAINS_NON_ALPHABET_NUMBER));
            }
            // if userIDValidator is true ==> 만약에 DB 에 유저의 값이 없다면,
            if (userDao.userIDValidator(userID)) {
                System.out.println("해당 아이디로 생성이 가능합니다.");
                return true;
            } else {
                System.out.println("뭔가 이상");
                return false;
            }
        } catch (Exception e) {

            return false;
        }
    }

    /**
     * 유저가 로그인 하려는 정보가 맞을 시 userManager 에서 유저 로그인 싱글톤을 불러와서
     * 로그인을 진행해주는 메소드
     *
     * @param user_id : 아이디
     * @param pw      : 비번
     */

    /**
     * === Login Flow ===
     * = userLogin(user_id, pw) =
     * -> user_id 와 password 를 받아와서 authUser 를 불러서 로그인 인증을 합니다
     * = authUser(user_id, pw) =
     * -> 유저에게 받은 user_id로 DB user 테이블에서 값이 있는지 확인합니다
     * -> 값이 없다면 해당 아이디를 쓰는 유저가 없음으로 null 값 return + [로그인 실패]
     * -> 값이 있다면 아이디를 쓰는 사람이 있음으로 인증완료 문구출력
     * -> storeUser 호출
     * = storeUser =
     * -> 해당 아이디로 DB 에서 찾아온 모든 User 값인 rs를 User에 저장
     * -> 값 저장 실패시 "값 저장 실패" 문구 출력
     * -> user return
     * -> 성공적으로 저장을 했으면 인증완료 문구 출력
     * = statusChecker(user) =
     * -> 로그인 인증이 끝난 로그인 할 유저의 계정의 status(상태)를 점검
     * -> request : 승인요청 가능, 요청 할건지 물어봄
     * -> Y 일시
     * = approveUser(user) !관리자전용! =
     * -> user 에서 status 를 request 에서 activate로 변경
     * -> N 일시 뒤로가기
     * -> DEACTIVATE, BANNED 는 로그인 불가능 및 문구 출력
     * -> ACTIVATE : 유일한 로그인 가능
     * -> 로그인시 UserStatus 로 return, 실패시 null return
     * -> statusChecker 의 return 값이 null 이 아닐시 [user return]
     * -> null 값일 시 [null return]
     * -> auth 의 return 값이 null 이 아닐경우
     * = loginUser(loggedInUser) =
     * -> 싱글톤 instance 를 생성해서 curUser = 로그인한유저 로그인
     * -> 해당 유저값 출력
     * -> return 값이 null 일 경우 "유저 로그인 실패" 출력
     */
    public void userLogin(String choice, String user_id, String pw) {
        try {
            //TODO:: DTO 내가 원하는 승객을 태워서 원하는 곳으로 보내는 셔틀 같은 느낌

            switch (choice) {
                // user(seller)
                case "2" -> {
                    User seller = userDao.authUser(user_id, pw);

                    if (seller != null) {
                        UserManager.getInstance().loginUser(seller);
                        UserRole role = UserManager.getInstance().getCurUser().getUserRole();
                        /**
                         * 권한별 사용법 (menu 에서 권한을 다르게 줘야댐)
                         * switch (role) {
                         *      case GENERAL_MANAGER -> {
                         *          // ...
                         *          // break;
                         *      }
                         *      case WAREHOUSE_MANAGER -> {
                         *          // ...
                         *          // break;
                         *      }
                         * }
                         */
                    } else {
                        System.out.println("유저 로그인 실패");
                    }
                }
                // customer
                case "3" -> {
                    Customer customer = userDao.authCustomer(user_id, pw);

                    if (customer != null) {
                        UserManager.getInstance().loginCustomer(customer);
                        UserRole role = UserManager.getInstance().getCurCustomer().getUserRole();
                        System.out.println(role);
                        System.out.println(UserManager.getInstance().getCurCustomer().getAddr1());
                    } else {
                        System.out.println("유저 로그인 실패");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void registerUser() {


    }




}
