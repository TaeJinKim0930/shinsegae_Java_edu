package Service;

public interface WarehouseService {

    void addWarehouse();
    void getWarehouse();
    void ClassifyWarehouse();

    void modifyWarehouse();

    void removeWarehouse();

}
