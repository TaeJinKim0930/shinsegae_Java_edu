package Entity;

import lombok.*;

@Data
@Getter
@NoArgsConstructor
public class WarehouseAddress {

    private int whAddressNo;
    private String whAddressName;

}
