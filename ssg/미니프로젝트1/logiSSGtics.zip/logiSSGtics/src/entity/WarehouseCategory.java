package Entity;

import lombok.*;

@Data
@Getter
@NoArgsConstructor
public class WarehouseCategory {

    private int topCategoryNum;
    private String topCategoryName;

}
