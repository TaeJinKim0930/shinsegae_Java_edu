import view.TotalMenu;

public class StartMain {
    public static void main(String[] args) {
        TotalMenu totalMenu = new TotalMenu();

        System.out.println("\n* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
        System.out.println("* ================================================================================================= *\n* ||"
                + "                                                                                             || *");
        System.out.println("* ||    L       OOO     GGGG   III    SSSS     SSSS      GGGG    TTTTT  III    CCCC    SSSS      || *");
        System.out.println("* ||    L      O   O   G    G   I    S    S   S    S    G    G     T     I    C    C   S    S    || *");
        System.out.println("* ||    L      O   O   G        I     S        S       G           T     I    C        S         || *");
        System.out.println("* ||    L      O   O   G  GGG   I      SSSS     SSS    G    GGG    T     I    C         SSSS     || *");
        System.out.println("* ||    L      O   O   G    G   I           S       S   G   G  G   T     I    C            S     || *");
        System.out.println("* ||    L      O   O   G    G   I    S    S        S    G    G     T     I    C    C   S    S    || *");
        System.out.println("* ||    LLLL    OOO     GGGG   III    SSSS     SSSS       GGGG     T    III    CCCC    SSSS      || *" +
                "\n* ||                                                                                             || *");
        System.out.println("* ================================================================================================= *" +
                "");
        System.out.println("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n\n\n");


        totalMenu.selectMenu();
    }
}
