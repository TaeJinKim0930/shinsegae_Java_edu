package com.example.jdbcex.dao;


import com.example.jdbcex.domain.TodoVO;
import com.zaxxer.hikari.HikariDataSource;
import lombok.Cleanup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;


public class TodoDAO {


    // 연결한 DB 커넥션 풀로부터 연결후 시간 select now() 쿼리 결과를 담아서 리턴하는 getTime() 메소드 작성

    public String getTime() {
        String sql = "select now()";
        String result = "";
        try (
                Connection conn = ConnectionUtil.INSTANCE.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql);
                ResultSet rs = pstmt.executeQuery();
        ) {
            if (rs.next()) {
                System.out.println("Get Time here");
                result = rs.getString(1);
            }
            return result;
        } catch (Exception e) {

        }
        return result;
    }

    /**
     * version 2 using @Cleanup that cleans up all the connection automatically
     *
     * @return
     * @throws Exception
     */
    public String getTime2() throws Exception {
        @Cleanup Connection conn = ConnectionUtil.INSTANCE.getConnection();
        @Cleanup PreparedStatement pstmt = conn.prepareStatement("select now()");
        @Cleanup ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            return rs.getString(1);
        } else {
            return "WRONG";
        }
    }

    // insert() method 는 param 으로 TodoVO 객체의 정보를 이용해서 INSERT 명령을 실행하여 주세요
    // values : title, finished
    public void insert(TodoVO todoVO) {
        String sql = "INSERT INTO tbl_todo (title, dueDate, finished) values (?,?,?)";
        try (
                Connection conn = ConnectionUtil.INSTANCE.getConnection();
                PreparedStatement pstmt = conn.prepareStatement(sql);
        ) {
            pstmt.setString(1, todoVO.getTitle());
            pstmt.setDate(2,todoVO.getDueDate().);
            pstmt.setBoolean(3, todoVO.isFinished());
            pstmt.execute();
            System.out.println("Insertion made");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}